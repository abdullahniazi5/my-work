package com.example.deepforge_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
